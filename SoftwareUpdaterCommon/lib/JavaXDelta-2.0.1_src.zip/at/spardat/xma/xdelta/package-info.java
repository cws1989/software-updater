/**
 * Package for creating delta files for .jar files.
 * 
 * Refer to {@link JarDelta} and {@link JarPatcher} for details.
 */
package at.spardat.xma.xdelta;